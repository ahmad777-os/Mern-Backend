const mongoose = require('mongoose');

const BookSchema = new mongoose.Schema({
  title: String,
  author: String,
  year: Number
});

const Book = mongoose.model('Book', BookSchema);
module.exports = Book;  // Corrected to export the 'Book' model.
