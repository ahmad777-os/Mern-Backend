const fs = require('fs');
const path = require('path');
const os = require('os');

console.log("Hello World");

fs.writeFileSync('hello.txt', 'This is written by Node.js');

console.log("File path:", path.join(__dirname, 'hello.txt'));
console.log("OS platform:", os.platform());
console.log("Free memory:", os.freemem()); 
// Importing Math.js
const add = require('./Math.js')
console.log(add(2,4))