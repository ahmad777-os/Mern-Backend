let books = require('../models/bookModel'); // import the book array

// GET /books
const getAllBooks = (req, res) => {
    res.json(books);
};

// GET /books/:id
const getBookById = (req, res) => {
    const id = parseInt(req.params.id);
    const book = books.find(b => b.id === id);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    res.json(book);
};

// POST /books
const addBook = (req, res) => {
    const { title, author, year } = req.body;
    const newBook = {
        id: books.length + 1, // simple ID generation
        title,
        author,
        year
    };
    books.push(newBook);
    res.status(201).json(newBook);
};

// PUT /books/:id
const updateBook = (req, res) => {
    const id = parseInt(req.params.id);
    const book = books.find(b => b.id === id);
    if (!book) return res.status(404).json({ message: 'Book not found' });

    const { title, author, year } = req.body;
    book.title = title || book.title;
    book.author = author || book.author;
    book.year = year || book.year;

    res.json(book);
};

// DELETE /books/:id
const deleteBook = (req, res) => {
    const id = parseInt(req.params.id);
    const index = books.findIndex(b => b.id === id);
    if (index === -1) return res.status(404).json({ message: 'Book not found' });

    const deleted = books.splice(index, 1);
    res.json({ message: 'Book deleted', book: deleted[0] });
};

module.exports = {
    getAllBooks,
    getBookById,
    addBook,
    updateBook,
    deleteBook
};
