const express = require('express');
const app = express();
const bookRoute = require('./routes/bookRoutes');
const logger = require('./middleware/logger'); 

app.use(express.json());
app.use(logger); // Use the logger before the routes
app.use('/api', bookRoute); // Mount routes

module.exports = app;
