const books = [
{id : 1, title: "Physics", author:"ahmad", year:22},
{id : 2, title: "Chemistry", author:"ahmad", year:22},
{id : 3, title: "Math", author:"ahmad", year:22},
{id : 4, title: "Biology", author:"ahmad", year:22},
]

module.exports = books;