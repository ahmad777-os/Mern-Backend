const express = require('express')
const app = express()
const userRouter = require('./routes/userRoutes.js')
app.use('/api', userRoutes)
module.exports = app