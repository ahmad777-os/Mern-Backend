// Simulating a user model (this could later connect to a database)
const users = [
  { id: 1, name: "ahmad" },
  { id: 2, name: "ali" },
];

module.exports = users;
