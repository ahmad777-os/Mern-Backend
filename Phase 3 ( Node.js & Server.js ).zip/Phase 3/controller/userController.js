const users = require('../models/userModel');

exports.getUser = (req, res) => {
  res.status(200).json(users);
};
