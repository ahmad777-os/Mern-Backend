const express = require('express');
const app = express();
const PORT = 3000;

app.listen(PORT, () => {
    console.log(`Server Running on Port: ${PORT}`);
});

// Root route
app.get('/', (req, res) => {
    res.send('Welcome to the homepage');
});

// POST request to root
app.post('/', (req, res) => {
    res.send('Post request received');
});

// PUT request to root
app.put('/', (req, res) => {
    res.send('Put request to update');
});

// DELETE request to root
app.delete('/', (req, res) => {
    res.send('Deleted');
});

// Route Parameter Example
app.get('/user/:id', (req, res) => {
    const userId = req.params.id;
    res.send(`User ID is: ${userId}`);
});

// Query String Example
app.get('/search', (req, res) => {
    const query = req.query.q;
    if (query) {
        res.send(`Search result for: ${query}`);
    } else {
        res.send('No search query provided');
    }
});
