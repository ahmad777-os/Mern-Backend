const express = require('express')
const app = express()
const PORT = 4000
// Making Middleware
const middleware = (req, res, next)=>{
    console.log("Middleware Runs!")
    next()
}
app.use (middleware)

// Making routes
app.get('/', (req, res)=>{
    console.log('Routes Run')
})
app.listen(PORT, (req, res)=>{
    console.log(`Server Runnig on PORT : ${PORT}`)
})